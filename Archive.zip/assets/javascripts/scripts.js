// @codekit-append "modernizr.js";
// @codekit-append "jquery-2.1.1.min.js";
// @codekit-append "jquery.placeholder.js";
// @codekit-append "jquery.magnific-popup.min.js";
// @codekit-append "owl.carousel.min.js";
// @codekit-append "jquery.waypoints.js";
// @codekit-append "photoswipe.min.js";
// @codekit-append "photoswipe-ui-default.min.js";